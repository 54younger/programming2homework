% Example taken from Matlab, see command:
% openExample('images/PlotTheGammaCurveOfSRGBAndAdobeRGBExample')
%% Plot Gamma Curve of sRGB and Adobe RGB
% Define a range of linear values. This vector defines 257 equally spaced points 
% between 0 and 1.

lin = linspace(0,1,257);
%% 
% Apply gamma correction to the linear values based on the sRGB standard. Then 
% apply gamma correction to the linear values based on the Adobe RGB (1998) standard.

sRGB = lin2rgb(lin);
adobeRGB = lin2rgb(lin,'ColorSpace','adobe-rgb-1998');
%%  Plot the gamma-corrected curves.

figure
plot(lin,sRGB,'b',lin,adobeRGB,'r')
xlabel('Linear values')
ylabel('Gamma corrected values')
title('Gamma Corrected vs. Linear Values')
legend('sRGB','Adobe RGB (1998)','Location','southeast')
%% For an alternative visualization, plot color bars representing each 
%  color space.

cb_lin = ones(30,257) .* lin;
cb_sRGB = ones(30,257) .* sRGB;
cb_adobeRGB = ones(30,257) .* adobeRGB;

figure
subplot(3,1,1); imshow(cb_lin); axis off; title('Linear RGB')
subplot(3,1,2); imshow(cb_sRGB); axis off; title('sRGB');
subplot(3,1,3); imshow(cb_adobeRGB); axis off; title('Adobe RGB (1998)');
%% 
% The gamma-corrected color spaces get brighter more quickly than the linear 
% color space, as expected. 
% _Copyright 2012 The MathWorks, Inc._